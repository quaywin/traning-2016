var student = { 
    name : "David Rayy", 
    sclass : "VI", 
    rollno : 12 
};
for(var i in student)
    console.log(i);
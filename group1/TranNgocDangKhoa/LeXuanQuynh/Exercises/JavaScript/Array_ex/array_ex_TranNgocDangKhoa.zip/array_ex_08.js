arr = [4, 3, 5];
console.log(arr);
arr.length = 0;
console.log(arr);
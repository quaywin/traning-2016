function type(para){
    return (typeof para);
}
console.log(type(undefined));
console.log(type("ddasf"));
console.log(type(31));